include "index.html" in contact, about us and faq's instead "home.html".
include "login as faculty,login as student,login as admin" in contact, about us and faq's pages.
