<?php
	$servername="localhost";
	$uname="root";
	$pswd="sagar@123";
	$conn=mysqli_connect($servername,$uname,$pswd,"college");
	if(!$conn){
		echo "Connection failed";
	}
	else{
		session_start();
		$a=$_SESSION['cid'];
		$b=$_SESSION['ssn'];
		//var_dump($a);
		//var_dump($b);
		//echo "</br>";

		for ($i=0 ;$i<sizeof($b);$i++) {
						@$ssn=htmlspecialchars($_REQUEST[$b[$i]]);
						ob_start();
						if($_POST[$ssn] == $ssn and $ssn != null)
						{
							ob_get_clean();
							$bd=$ssn;
							ob_start();
						}
						ob_get_clean();

}
	//echo $bd;
		for ($i=0 ;$i<sizeof($a);$i++) {
					//echo $a[$i];
						//echo "</br>";
					$cid=$a[$i];

					@$at=$_POST[$cid];
					//echo $cid ;
					//echo "<br>";
					$ab = $_POST[$bd];
					//echo $ab;
					$qr="update attended set attendence='$at' where c_id='$cid' and ssn='$bd'";
					mysqli_query($conn,$qr);
}
		session_destroy();
		include "del_upd1.php";
		echo "Upated successfully";
 }
 ?>
